import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FerryTicketGUI extends JFrame {
    private JLabel fromLabel, toLabel, dateLabel, passengersLabel;
    private JTextField fromTextField, toTextField, dateTextField, passengersTextField;
    private JButton bookTicketsButton;
    private JTextArea detailsTextArea;

    public FerryTicketGUI() {
        // Set frame properties
        setTitle("Ferry Ticket Booking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);

        // Initialize components
        fromLabel = new JLabel("From:");
        toLabel = new JLabel("To:");
        dateLabel = new JLabel("Departure Date:");
        passengersLabel = new JLabel("Number of Passengers:");

        fromTextField = new JTextField(10);
        toTextField = new JTextField(10);
        dateTextField = new JTextField(10);
        passengersTextField = new JTextField(5);

        bookTicketsButton = new JButton("Book Tickets");
        detailsTextArea = new JTextArea(10, 30);

        // Set layout manager (you can use others like GridLayout, etc.)
        setLayout(new FlowLayout());

        // Add components to the frame
        add(fromLabel);
        add(fromTextField);
        add(toLabel);
        add(toTextField);
        add(dateLabel);
        add(dateTextField);
        add(passengersLabel);
        add(passengersTextField);
        add(bookTicketsButton);
        add(detailsTextArea);

        // Add action listener to the "Book Tickets" button
        bookTicketsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Retrieve user input
                String from = fromTextField.getText();
                String to = toTextField.getText();
                String date = dateTextField.getText();
                int numPassengers = Integer.parseInt(passengersTextField.getText());

                // Check availability (you should implement your own availability logic)
                boolean isAvailable = checkAvailability(from, to, date, numPassengers);

                if (isAvailable) {
                    // Calculate ticket price (you can implement your own pricing logic)
                    double ticketPrice = calculateTicketPrice(from, to, date, numPassengers);

                    // Display booking details
                    String bookingDetails = "From: " + from + "\nTo: " + to + "\nDate: " + date +
                            "\nPassengers: " + numPassengers + "\nTotal Price: $" + ticketPrice;
                    detailsTextArea.setText(bookingDetails);

                    // Store booking information (you should implement your own storage logic)
                    storeBooking(from, to, date, numPassengers, ticketPrice);
                } else {
                    // Display a message if tickets are not available
                    detailsTextArea.setText("Tickets are not available for the selected route and date.");
                }
            }
        });
    }

    // Placeholder methods for checking availability, calculating price, and storing booking
    private boolean checkAvailability(String from, String to, String date, int numPassengers) {
        // Implement your own availability logic here
        return true;
    }

    private double calculateTicketPrice(String from, String to, String date, int numPassengers) {
        // Implement your own pricing logic here
        return 100.0; // Replace with actual pricing calculation
    }

    private void storeBooking(String from, String to, String date, int numPassengers, double ticketPrice) {
        // Implement your own storage logic here
        // This can include database operations or file I/O
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new FerryTicketGUI().setVisible(true);
            }
        });
    }
}
